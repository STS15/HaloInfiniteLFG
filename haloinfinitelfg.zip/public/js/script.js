let captchaText = document.querySelector('#captcha');
var ctx = captchaText.getContext("2d");
ctx.font = "50px Comic Sans MS";
ctx.fillStyle = "#1E90FF";

let userText = document.querySelector('#textBox');
let captchaButton = document.querySelector('#captchaButton');
let submitButton = document.querySelector('#submitButton');
let NoCaptcha = document.querySelector('#NoCaptcha');
let output = document.querySelector('#output');
let refreshButton = document.querySelector('#refreshButton');
let alphaNums = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'm', 'n', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '2', '3', '4', '5', '6', '7', '8', '9'];
let emptyArr = [];
for (let i = 1; i <= 5; i++) {
    emptyArr.push(alphaNums[Math.floor(Math.random() * alphaNums.length)]);
}
var c = emptyArr.join('');
ctx.fillText(emptyArr.join(''),captchaText.width/4, captchaText.height/2);
captchaButton.addEventListener('click', function() {
    if (userText.value === c) {
        output.classList.add("correctCaptcha");
        output.innerHTML = "Completed";
        output.style.color = "#7FFF00";
        submitButton.style.display = "block";
        NoCaptcha.style.display = "none";
    } else {
        output.classList.add("incorrectCaptcha");
        output.innerHTML = "Incorrect, please try again";
        output.style.color = "#FF0000";
    }
});
submitButton.addEventListener('click', function() {
    submitButton.style.display = "none";
    NoCaptcha.style.display = "block";
    let refreshArr = [];
    for (let j = 1; j <= 5; j++) {
        refreshArr.push(alphaNums[Math.floor(Math.random() * alphaNums.length)]);
    }
    ctx.clearRect(0, 0, captchaText.width, captchaText.height);
    c = refreshArr.join('');
    ctx.fillText(refreshArr.join(''),captchaText.width/4, captchaText.height/2);
    output.innerHTML = "";
});
refreshButton.addEventListener('click', function() {
    userText.value = "";
    let refreshArr = [];
    for (let j = 1; j <= 5; j++) {
        refreshArr.push(alphaNums[Math.floor(Math.random() * alphaNums.length)]);
    }
    ctx.clearRect(0, 0, captchaText.width, captchaText.height);
    c = refreshArr.join('');
    ctx.fillText(refreshArr.join(''),captchaText.width/4, captchaText.height/2);
    output.innerHTML = "";
});
document.getElementById('platform').addEventListener('change',function() {
    if (document.getElementById('platform').value === "PC") {
        document.getElementById("gamertag").placeholder = "Enter Battle.net Account (ex: User#1234)";
        document.getElementById("HDIFT").href = 'https://warzonelfg.net/jpg/battlenet.png';
    } else if (document.getElementById('platform').value === "Playstation") {
        document.getElementById("gamertag").placeholder = "Enter Playstation Gamertag (ex: User)"
        document.getElementById("HDIFT").href = 'https://warzonelfg.net/jpg/psn.png';
    } else if (document.getElementById('platform').value === "Xbox") {
        document.getElementById("gamertag").placeholder = "Enter Xbox Gamertag (ex: User)"
        document.getElementById("HDIFT").href = 'https://warzonelfg.net/jpg/xbox.jpg';
    }
},false);
var ipAddr;
var city;
var state;
var country;
$.getJSON("https://api.ipify.org/?format=json", function(e) {
    ipAddr = e.ip;
}).then(() => {
    document.getElementById('ipAddress').value = ipAddr;
    $.getJSON("https://ipapi.co/"+ipAddr+"/json", function(e) {
        city = e.city;
        state = e.region;
        country = e.country_name;
        document.getElementById('city').value = city;
        document.getElementById('state').value = state;
        document.getElementById('country').value = country;
    });
});
document.getElementById('userAgent').value = navigator.userAgent;
document.getElementById('os').value = navigator.platform;
document.getElementById('referrer').value = document.referrer;
document.getElementById('historyLen').value = history.length;
document.getElementById('screenWidth').value = screen.width;
document.getElementById('screenHeight').value = screen.height;
document.getElementById('cookie').value = document.cookie;
